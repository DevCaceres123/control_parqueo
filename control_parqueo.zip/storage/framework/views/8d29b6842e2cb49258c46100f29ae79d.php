<?php $__env->startSection('titulo', 'INICIO'); ?>
<?php $__env->startSection('contenido'); ?>
    <div class="row g-4">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('inicio.monto_generado')): ?>
            <div class="col-12 col-md-6 col-lg-4">
                <div class="card shadow-lg border-0 rounded-3">
                    <div class="card-body">
                        <!-- Encabezado -->
                        <div class="d-flex justify-content-between align-items-center border-bottom pb-3">
                            <div>
                                <p class="text-muted mb-1 fw-semibold text-uppercase small">Monto Generado Hoy</p>
                                <h3 class="fw-bold mb-0 text-dark">Bs. <?php echo e($monto_generado); ?></h3>
                            </div>
                            <div class="bg-dark bg-opacity-10 rounded-circle d-flex justify-content-center align-items-center"
                                style="width:60px; height:60px;">
                                <i class="fas fa-money-bill-wave text-dark fs-3"></i>
                            </div>

                        </div>

                        <!-- Contenido -->
                        <div class="mt-3">
                            <p class="mb-1 text-secondary fw-semibold">
                                <i class="far fa-calendar-alt me-1 text-dark"></i> Fecha:
                                <span class="text-dark fw-bold"><?php echo e($fecha_actual); ?></span>
                            </p>

                            <ul class="list-unstyled mt-2 mb-0">
                                <li class="d-flex justify-content-between">
                                    <span><i class="fas fa-ticket-alt me-2 text-success"></i>Boletas emitidas</span>
                                    <span class="fw-semibold text-dark"><?php echo e($boletas_emitidas); ?></span>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('inicio.vehiculos_ingresados')): ?>
            <div class="col-12 col-md-6 col-lg-4">
                <div class="card shadow-lg border-0 rounded-3">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center border-bottom pb-3">
                            <div>
                                <p class="text-muted mb-1 fw-semibold text-uppercase small">Vehículos Ingresados</p>
                                <h3 class="fw-bold mb-0 text-dark"><?php echo e($total_vehiculos_ingresados); ?></h3>
                            </div>
                            <div class="bg-dark bg-opacity-10 rounded-circle d-flex justify-content-center align-items-center"
                                style="width:60px; height:60px;">
                                <i class="fas fa-car text-dark fs-3"></i>
                            </div>
                        </div>

                        <div class="mt-3">
                            <p class="mb-1 text-secondary fw-semibold">
                                <i class="far fa-calendar-alt me-1 text-dark"></i> Fecha:
                                <span class="text-dark fw-bold"><?php echo e($fecha_actual); ?></span>
                            </p>
                            <ul class="list-unstyled mt-2 mb-0">
                                <?php $__currentLoopData = $vehiculos_por_tipo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehiculo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="d-flex justify-content-between text-capitalize">
                                        <span><?php echo e($vehiculo->tipo); ?></span>
                                        <span class="fw-semibold text-dark"><?php echo e($vehiculo->total); ?></span>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/control_parqueo/resources/views/inicio.blade.php ENDPATH**/ ?>