<?php $__env->startSection('titulo', 'REPORTES'); ?>
<?php $__env->startSection('contenido'); ?>

    <div class="row justify-content-center">
    <div class="col-12 col-md-10 col-lg-8">
        <div class="card shadow-lg border-0 rounded-4">
            <div class="card-header bg-dark text-white text-center rounded-top-4 p-3">
                <h4 class="card-title mb-0 fw-bold fs-5 text-uppercase">
                    <i class="fas fa-file-archive  me-1"></i> Reporte de Boletas
                </h4>
            </div>
            <div class="card-body p-4">
                <form id="form-reporte_usuario">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label for="fecha_inicio_usuario" class="form-label fw-semibold">Fecha de Inicio</label>
                            <input type="date" class="form-control" id="fecha_inicio_usuario"
                                name="fecha_inicio_usuario" value="<?php echo e(\Carbon\Carbon::now()->format('Y-m-d')); ?>" required>
                            <div class="invalid-feedback">
                                Por favor, seleccione una fecha de inicio.
                            </div>
                        </div>
                        <div class="col-md-6">
                            <label for="fecha_final_usuario" class="form-label fw-semibold">Fecha de Final</label>
                            <input type="date" class="form-control" id="fecha_final_usuario"
                                name="fecha_final_usuario" value="<?php echo e(\Carbon\Carbon::now()->format('Y-m-d')); ?>" required>
                            <div class="invalid-feedback">
                                Por favor, seleccione una fecha de finalización.
                            </div>
                        </div>

                        <div class="col-12 mt-4">
                            <label class="form-label fw-semibold">Seleccionar Encargado(s) de Puesto</label>
                            <div class="border border-secondary rounded p-3 bg-light">
                                <div class="form-check form-check-inline mb-2">
                                    <input class="form-check-input" type="checkbox" id="select_all_user">
                                    <label class="form-check-label fw-bold" for="select_all_user">
                                        Seleccionar Todos
                                    </label>
                                </div>
                                <hr class="my-2">
                                <div class="row" id="mesesPagados">
                                    <?php $__currentLoopData = $encargados_puesto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $encargados): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-12 col-md-6">
                                            <div class="form-check mt-2">
                                                <input class="form-check-input" type="checkbox" id="user_<?php echo e($encargados->id); ?>"
                                                    name="encargados_puesto[]" value="<?php echo e($encargados->id); ?>">
                                                <label class="form-check-label text-uppercase" for="user_<?php echo e($encargados->id); ?>">
                                                    <?php echo e($encargados->nombres); ?> <?php echo e($encargados->apellidos); ?>

                                                </label>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                    
                                </div>
                            </div>
                        </div>

                        <div class="col-12 mt-4 text-center">
                            <button type="submit" class="btn btn-primary btn-lg px-5 fw-bold shadow-sm" id="btn-reporte_usuario">
                                <i class="fas fa-file-alt me-2"></i> Generar Reporte
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

    <script>
        document.addEventListener("DOMContentLoaded", function() {

            let fecha_inicio_usuario = document.getElementById("fecha_inicio_usuario");
            let fecha_final_usuario = document.getElementById("fecha_final_usuario");
         
            // Al cambiar la fecha de inicio, actualizamos el mínimo de la fecha final
            fecha_inicio_usuario.addEventListener("change", function() {
                fecha_final_usuario.min = fecha_inicio_usuario.value;
            });

            // Al cambiar la fecha final, actualizamos el máximo de la fecha de inicio
            fecha_final_usuario.addEventListener("change", function() {
                fecha_inicio_usuario.max = fecha_final_usuario.value;
            });

        });
      
    </script>

    <script src="<?php echo e(asset('js/modulos/reporte/reporte.js')); ?>" type="module"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/control_parqueo/resources/views/administrador/reportes/reportes.blade.php ENDPATH**/ ?>