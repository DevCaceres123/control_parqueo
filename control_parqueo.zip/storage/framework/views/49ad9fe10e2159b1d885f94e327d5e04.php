<div class="startbar d-print-none">
    <!--start brand-->
    <div class="brand">
        <div class="logo" style="display: block ; width: 100% !important; height: 70px; overflow: hidden;">
            <span style="width: 100%; height: 100%;">
                <img src="<?php echo e(asset('assets/logo-caranavi.webp')); ?>" alt="logo-small" class="" width="70px"
                    height="70px" style="object-fit: contain">
            </span>
            <span class="">

            </span>
        </div>
    </div>
    <!--end brand-->
    <!--start startbar-menu-->
    <div class="startbar-menu">
        <div class="startbar-collapse" id="startbarCollapse" data-simplebar>
            <div class="d-flex align-items-start flex-column w-100">
                <!-- Navigation -->
                <ul class="navbar-nav mb-auto w-100">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('inicio')): ?>
                        <li class="menu-label pt-0 mt-0">
                            <span>MENU</span>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('inicio')); ?>" role="button" aria-expanded="false"
                                aria-controls="sidebarDashboards">
                                <i class="iconoir-home-simple menu-icon"></i>
                                <span>INICIO</span>
                            </a>
                        </li><!--end nav-item-->
                    <?php endif; ?>
                    <li class="nav-item">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
                            <a class="nav-link" href="#usuarios" data-bs-toggle="collapse" role="button"
                                aria-expanded="false" aria-controls="usuarios">
                                <i class="iconoir-fingerprint-lock-circle menu-icon"></i>
                                <span>ADMIN USUARIOS</span>
                            </a>
                            <div class="collapse " id="usuarios">
                                <ul class="nav flex-column">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.usuario.inicio')): ?>
                                        <li class="nav-item">
                                            <a class="nav-link" href="<?php echo e(route('user.index')); ?>">Usuarios</a>
                                        </li>
                                    <?php endif; ?>

                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.rol.inicio')): ?>
                                        <li class="nav-item">
                                            <a class="nav-link" href="<?php echo e(route('roles.index')); ?>">Roles</a>
                                        </li>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.permiso.inicio')): ?>
                                        <li class="nav-item">
                                            <a class="nav-link" href="<?php echo e(route('permisos.index')); ?>">Permisos</a>
                                        </li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                    </li>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('control')): ?>
                        <li class="menu-label mt-2">
                            <small class="label-border">
                                <div class="border_left hidden-xs"></div>
                                <div class="border_right"></div>
                            </small>
                            <span>Boletas</span>
                        </li>
                    <?php endif; ?>


                    <li class="nav-item">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('control')): ?>
                            <a class="nav-link" href="#boleta" data-bs-toggle="collapse" role="button"
                                aria-expanded="false" aria-controls="boleta">
                                <i class="fas fa-file-invoice menu-icon"></i>
                                <span>CONTROL BOLETAS</span>
                            </a>
                        <?php endif; ?>
                        <div class="collapse " id="boleta">
                            <ul class="nav flex-column">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('control.boleta.inicio')): ?>
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(route('boletas.index')); ?>">Generar Boletas</a>
                                    </li>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('control.listar_boleta.inicio')): ?>
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(route('listarBoletas.index')); ?>">Listar Boletas</a>
                                    </li>
                                <?php endif; ?>

                            </ul>
                        </div>
                    </li>


                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reportes')): ?>
                        <li class="menu-label mt-2">
                            <small class="label-border">
                                <div class="border_left hidden-xs"></div>
                                <div class="border_right"></div>
                            </small>
                            <span>REPORTES</span>
                        </li>
                    <?php endif; ?>


                    <li class="nav-item">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reportes')): ?>
                            <a class="nav-link" href="#reporte" data-bs-toggle="collapse" role="button"
                                aria-expanded="false" aria-controls="reporte">
                                <i class="fas fa-chart-bar menu-icon"></i>
                                <span>REPORTES</span>
                            </a>
                        <?php endif; ?>

                        <div class="collapse " id="reporte">
                            <ul class="nav flex-column">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reportes.inicio')): ?>
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(route('reportes.index')); ?>">Reportes</a>
                                    </li>
                                <?php endif; ?>

                            </ul>
                        </div>
                    </li>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('config')): ?>
                        <li class="menu-label mt-2">
                            <small class="label-border">
                                <div class="border_left hidden-xs"></div>
                                <div class="border_right"></div>
                            </small>
                            <span>CONFIGURACIÓN</span>
                        </li>
                    <?php endif; ?>


                    <li class="nav-item">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('config')): ?>
                            <a class="nav-link" href="#configuracion" data-bs-toggle="collapse" role="button"
                                aria-expanded="false" aria-controls="configuracion">
                                <i class="fas fa-cog menu-icon"></i>
                                <span>CONFIGURACION</span>
                            </a>
                        <?php endif; ?>
                        <div class="collapse " id="configuracion">
                            <ul class="nav flex-column">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('config.vehiculos.inicio')): ?>
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(route('vehiculos.index')); ?>">Tipo Vehiculos</a>
                                    </li>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('config.atraso.inicio')): ?>
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(route('atraso.index')); ?>">Conf. Atraso</a>
                                    </li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('config.colores.inicio')): ?>
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(route('colores.index')); ?>">Colores</a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </li>




                </ul><!--end navbar-nav--->
            </div>
        </div><!--end startbar-collapse-->
    </div><!--end startbar-menu-->
</div>
<div class="startbar-overlay d-print-none"></div>
<?php /**PATH /var/www/html/control_parqueo/resources/views/plantilla_admin/menu.blade.php ENDPATH**/ ?>